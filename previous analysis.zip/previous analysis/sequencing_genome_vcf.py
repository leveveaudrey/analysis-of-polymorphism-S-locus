#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import os
import sys
import subprocess
import utils
import argparse
import base64
from Bio import Seq
from Bio import SeqIO
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
from collections import OrderedDict

__version__ = "1.0"

args = None

def run(ArgsVal):
    global args

    description = """ Analyse Données Capture """

    parser = argparse.ArgumentParser(prog="Analyse_Capture",description=description)

    parser.add_argument("-V", "--verbose", help="full verbose", action="store_const", const="-V", default="")
    parser.add_argument("-t", "--test", help=argparse.SUPPRESS, action="store_const", const="-t", default="")
    parser.add_argument("-f", "--force", action="store_const", const="-f", default="")
    parser.add_argument("-d", "--indivdepth", help="add individuals depth to TAB_REPORT",action="store_const", const="-d", default="")
    parser.add_argument("-c", "--checks", help=argparse.SUPPRESS, action="store_const", const="-c", default="")

    parser.add_argument('-v', '--version', action='version', version='%(prog)s ' + __version__)

    parser.add_argument("-o","--outFolder", help="output folder", required = True)
    parser.add_argument("-r","--refFasta", help="reference fasta file", required = True)
    parser.add_argument("-i","--fastqList", help="input fastq reads list", required = True)
    parser.add_argument("-b","--bedfile", help="bed file", required = True)
    parser.add_argument("-p","--ploidy", help="sample ploidy (2 by default)")

    args = parser.parse_args(ArgsVal)

    outFolder = args.outFolder
    refFasta = args.refFasta

    ploidy = 2

    if args.ploidy:
        ploidy = int(args.ploidy)
    
    fastaDic = {}
    fasta = SeqIO.parse(refFasta,"fasta")

    for rec in fasta:
        fastaDic[rec.id]=str(rec.seq)
    fasta.close

    fastqList = args.fastqList
    bedFile = args.bedfile

    #nombre max de jobs en parallèle
    maxPjobs = 20
    utils.setMaxParallelJobsToConfig(maxPjobs)

    check_refIUPAC(refFasta)

    dirFile_exist(outFolder,1)
    dirFile_exist(refFasta)
    dirFile_exist(fastqList)
    dirFile_exist(bedFile)

    readsDir, readsDic = load_readsList(fastqList)
    indivList = readsDic.keys()
    refName = refFasta[refFasta.rfind('/')+1:refFasta.rfind('.')]

    #out folders
    outRsltAln = os.path.join(outFolder,"Alignments")
    outRsltMD = os.path.join(outFolder,"MarkDuplicates")
    outRsltTI = os.path.join(outFolder,"Target_Intersect")
    outRsltHC = os.path.join(outFolder,"HaplotypeCaller")
    dirFile_exist(outRsltAln,1)
    dirFile_exist(outRsltMD,1)
    dirFile_exist(outRsltTI,1)
    dirFile_exist(outRsltHC,1)

    AlnNames = {i:"{}_{}".format(refName,i) for i in indivList}

    #Workflow
    refIndex(refFasta,refName)

    AlnbamDic = mappingOnRef(indivList,AlnNames,readsDir,readsDic,refFasta,outRsltAln)

    samtools_stat(AlnbamDic,outRsltAln)

    inBamPPSDic = bamPpSortIndex(AlnbamDic,AlnNames,outRsltAln)

    remove_files(AlnbamDic)

    plotCoveragePPS(inBamPPSDic,AlnNames,outRsltAln)

    inBamPPSMdDic = MarkDuplicates(inBamPPSDic,AlnNames,outRsltMD)

    remove_files(inBamPPSDic)

    inBamPPSMdTiDic = TargetIntersect(inBamPPSMdDic,AlnNames,outRsltTI,bedFile)

    remove_files(inBamPPSMdDic)

    inVCF = HaplotypeCaller_GVCF(inBamPPSMdTiDic,AlnNames,outRsltHC,refFasta,refName,ploidy)

    remove_files(inBamPPSMdTiDic)

    vcfAnalsed = vcfAnalyse(inVCF,outRsltHC,refName,ploidy)
    
    print "END..."

def remove_files(outdic):
    pass
    return 0
    print("Clean files:")
    for indiv,rmfile in outdic.items():
        if os.path.exists(rmfile):
            os.remove(rmfile)
            print("\t{}: remove file '{}'".format(indiv,rmfile))
        else:
            print("\tCan't remove {}".format(rmfile))

def refIndex(refFasta,refName):
    print "Index reference..."
    refDir = os.path.dirname(refFasta)
    refFileName = os.path.basename(refFasta)

    if not os.path.exists(os.path.join(refDir,"{}.1.bt2".format(refName))):
        cmd = "bowtie2-build {} {}".format(refFasta,os.path.join(refDir,refName))
        os.system(cmd)

    if not os.path.exists(os.path.join(refDir,"{}.fai".format(refFileName))):
        cmd = "samtools faidx {}".format(refFasta)
        os.system(cmd)

    if not os.path.exists(os.path.join(refDir,"{}.dict".format(refName))):
        cmd = "java -jar /gepv/tools/picard-tools-1.119/CreateSequenceDictionary.jar R= {ref} O= {dicName}".format(ref=refFasta,dicName=os.path.join(refDir,"{}.dict".format(refName)))
        os.system(cmd)

def mappingOnRef(indivList,AlnNames,readsDir,readsDic,refFasta,outFolder):

    print "Launch Alignments..."

    jblst = utils.Jobslist("bowtie2 for all")

    outputReturn = {}

    for indiv in indivList:
        outIndivRslt = os.path.join(outFolder,indiv)
        dirFile_exist(outIndivRslt,1)
        FwdRevDic={0:[],1:[]}
        for i,fqname in enumerate(readsDic[indiv]):
            FwdRevDic[i%2].append(os.path.join(readsDir,fqname))
                
        fwdFile = ",".join(FwdRevDic[0])
        revFile = ",".join(FwdRevDic[1])
        stderrFile = os.path.join(outIndivRslt,get_alnFileName(AlnNames,indiv,"stderr"))
        bamFileName = os.path.join(outIndivRslt,get_alnFileName(AlnNames,indiv,"Aln",".bam"))

        cmd="bowtie2 --phred33 --rg-id {alnName} --rg SM:{ind} --minins 0 --maxins 1000 -x {ref} -1 {fwd} -2 {rev} - 2> {stderr} | samtools view -b -h -S -F 0x4 - > {bamname}".format(alnName=AlnNames[indiv],ind=indiv,ref=refFasta[:refFasta.rfind('.')],fwd=fwdFile,rev=revFile,stderr=stderrFile,bamname=bamFileName)
        
        target= bamFileName
        jblst.add_a_job(cmd,"bowtie2 {}".format(AlnNames[indiv]),target)
        outputReturn[indiv] = bamFileName

    utils.trun(args, jblst)

    return outputReturn

def samtools_stat(inBamDic,outFolder):

    print "Launch samtools stats..."

    jblst = utils.Jobslist("samtoolstats for all")

    for indiv,bamfile in inBamDic.items():
        outIndivRslt = os.path.join(outFolder,indiv)
        samtoolStatsERRFile = os.path.join(outIndivRslt,"samtools_stats_stderr.txt")
        samtoolStatsFile = os.path.join(outIndivRslt,"samtools_stats.txt")
        cmd = "samtools stats {bam} 2>> {errStats} | grep ^SN | cut -f2- >> {stats}".format(bam=bamfile,errStats=samtoolStatsERRFile,stats=samtoolStatsFile)
        target = samtoolStatsFile
        jblst.add_a_job(cmd,"samtoolstats {}".format(indiv),target)

    utils.trun(args, jblst, False)
    
def bamPpSortIndex(inBamDic,AlnNames,outFolder):
    
    print "Launch bam filter sort and index..."

    jblst = utils.Jobslist("PP SORT INDEX")
    outputReturn = {}
    ppremove=[]

    for indiv,bamfile in inBamDic.items():
        outIndivRslt = os.path.join(outFolder,indiv)
        ppname=os.path.join(outIndivRslt,get_alnFileName(AlnNames,indiv,"Aln","_PP.bam"))
        ppsort=os.path.join(outIndivRslt,get_alnFileName(AlnNames,indiv,"Aln","_PPS.bam"))

        cmd="samtools view -f 2 -b {bam} > {ppbam} && samtools sort {ppbam} -o {ppsort} && samtools index {ppsort}".format(bam=bamfile,ppbam=ppname,ppsort=ppsort)
        target = ppsort
        outputReturn[indiv] = ppsort
        ppremove.append(ppname)
        jblst.add_a_job(cmd,"PP SORT INDEX {}".format(indiv),target)

    utils.trun(args, jblst)
    for rmfile in ppremove:
        if os.path.exists(rmfile):
            os.remove(rmfile)
            print("\tremove {}".format(rmfile))
        else:
            print("\tCan't remove {}".format(rmfile))
    return outputReturn

def plotCoveragePPS(inBamDic,AlnNames,outFolder):
    
    print "Launch plotCoverage..."

    jblst = utils.Jobslist("plotcoverage")

    for indiv,bamfile in inBamDic.items():
        outIndivRslt = os.path.join(outFolder,indiv)
        plotCoverage = os.path.join(outIndivRslt,get_alnFileName(AlnNames,indiv,"Aln","_coverage.png"))
        PcOut = os.path.join(outIndivRslt,get_alnFileName(AlnNames,indiv,"Aln","_coverage.out"))
        cmd = "plotCoverage -p 1 -b {bam} -o {plotcov} > {out}".format(bam=bamfile,plotcov=plotCoverage,out=PcOut)
        target = plotCoverage
        jblst.add_a_job(cmd,"plotCoverage {}".format(indiv),target)

    utils.trun(args, jblst, False)

def MarkDuplicates(inBamDic,AlnNames,outFolder):
    
    print "Launch MarkDuplicates (can take a while)..."

    MatrixFolder = os.path.join(outFolder,"Matrix_data")
    dirFile_exist(MatrixFolder,1)
    outputReturn = {}
    print "{} files to analyse".format(len(inBamDic.keys()))
    n=0
    for indiv,bamfile in inBamDic.items():
        n+=1
        bamMD = os.path.join(outFolder,get_alnFileName(AlnNames,indiv,"Aln","_PPSMd.bam"))
        MatrixFile = os.path.join(MatrixFolder,get_alnFileName(AlnNames,indiv,"Aln","_PPsMd_MATRIX"))
        MdStderr = os.path.join(outFolder,"markduplicates_stderr")
        MdStdout = os.path.join(outFolder,"markduplicates_stdout")

        cmd = "java -jar /gepv/tools/picard-tools-1.119/MarkDuplicates.jar I={bam} O={ppsmd} M={matrixmd} REMOVE_DUPLICATES=true AS=true 2>> {mdstderr} >> {mdstdout}".format(bam=bamfile,ppsmd=bamMD,matrixmd=MatrixFile,mdstderr=MdStderr,mdstdout=MdStdout)
        
        outputReturn[indiv] = bamMD

        if not os.path.exists(bamMD) or args.force:
            print "{} - Launch Markduplicates for {}".format(n,indiv)
            os.system(cmd)
    print "MarkDuplicates end..."

    return outputReturn

def TargetIntersect(inBamDic,AlnNames,outFolder,bedfile):

    print "Launch TargetIntersect..."

    jblst = utils.Jobslist("Target Intersect")
    outputReturn = {}

    for indiv,bamfile in inBamDic.items():
        bamTI = os.path.join(outFolder,get_alnFileName(AlnNames,indiv,"Aln","_PPSMdTi.bam"))
        bamTIbai = os.path.join(outFolder,get_alnFileName(AlnNames,indiv,"Aln","_PPSMdTi.bam.bai"))
        cmd="bedtools intersect -b {bed} -a {bam} > {tibam} &&  samtools index {tibam} {bai}".format(bed=bedfile,bam=bamfile,tibam=bamTI,bai=bamTIbai)
        target = bamTI
        outputReturn[indiv] = bamTI
        jblst.add_a_job(cmd,"Target Intersect {}".format(indiv),target)

    utils.trun(args, jblst)
    return outputReturn

def HaplotypeCaller_GVCF(inBamDic,AlnNames,outFolder,refFasta,refName,ploidy):

    print "Launch HaplotypeCaller GVCF..."

    jblst = utils.Jobslist("samtools depth")

    gvcfFld = os.path.join(outFolder,"gvcf")
    dirFile_exist(gvcfFld,1)

    bamHC_fld = os.path.join(outFolder,"bam_HC")
    dirFile_exist(bamHC_fld,1)

    depth_fld = os.path.join(outFolder,"bam_HC_depth")
    dirFile_exist(depth_fld,1)

    gvcfFileList = os.path.join(outFolder,"gvcf_data.list")

    outVCF = os.path.join(outFolder,"GATK_HC_{}.vcf".format(refName))
    outStderr = os.path.join(outFolder,"GATK_HC_stderr")
    outStdout = os.path.join(outFolder,"GATK_HC_stdout")

    if not os.path.exists(outVCF):

        gvcfList = list()
        for bamfile in inBamDic.values():
            bamName = os.path.basename(bamfile).split('.bam')[0]
            HC_outbam = os.path.join(bamHC_fld,"{}_HC_realigned.bam".format(bamName))
            gvfcFile = os.path.join(gvcfFld,"{}.g.vcf".format(bamName))            
            gvcfList.append(gvfcFile)

            if not os.path.exists(gvfcFile) or not os.path.exists(HC_outbam):
                cmd="GATK -R {ref} -T HaplotypeCaller -I {bam} -bamout {outbam} --emitRefConfidence GVCF --genotyping_mode DISCOVERY --sample_ploidy {pl} -o {gvcf} 2>> {GATKerr} >{GATKout}".format(ref=refFasta,bam=bamfile,gvcf=gvfcFile,GATKerr=outStderr,GATKout=outStdout,pl=ploidy,outbam=HC_outbam)
                os.system(cmd)
            depth_name=os.path.join(depth_fld,"{}_DEPTH.txt".format(bamName))
            cmd="samtools depth -o {depthname} {inbam_name}".format(depthname=depth_name,inbam_name=HC_outbam)
            jblst.add_a_job(cmd,"samtools depth",depth_name)

        utils.trun(args, jblst, False)

        f = open(gvcfFileList,"w")
        f.write("\n".join(gvcfList))
        f.close()
        #Merge gvcf files
        cmd = "GATK -T GenotypeGVCFs -R {ref} --variant {gvcfLst} -o {vcf}".format(ref=refFasta,gvcfLst=gvcfFileList,vcf=outVCF)
        os.system(cmd)

    return outVCF
    
def samtools_depth_informatio(inbam,outfolder):
    bamName = os.path.basename(inbam).split('.bam')[0]

def get_indivListFromVCF(vcfFile):
    vcf = open(vcfFile,"r")
    for line in vcf:
        if "#CHROM" in line:
            tmpline = line.strip()
            break
    vcf.close()
    indivList = tmpline.strip().split('\t')[9:]
    return indivList

def get_alleles_fromVCF(vcfFile,outCSV):
    indivList = get_indivListFromVCF(vcfFile)
    out = "SeqId\tPos\tAlt\t{}\n".format("\t".join([ind.replace("PL:ILLUMINA","").strip() for ind in indivList]))
    vcf = open(vcfFile,"r")
    for line in vcf:
        if "#" not in line[0]:
            tmpline = line.strip().split('\t')
            seqId = tmpline[0]
            pos = tmpline[1]
            alt = tmpline[4]
            GT = "\t".join([v.split(':')[0] for v in tmpline[9:]])
            out += "{sid}\t{p}\t{a}\t{g}\n".format(sid=seqId,p=pos,a=alt,g=GT)
    vcf.close()
    
    outf = open(outCSV,"w")
    outf.write(out)
    outf.close()

def calcul_div_allelique(inFreqFile,outName):
    outFile = open(outName,"w")
    inFile = open(inFreqFile,"r")
    inFile.readline()

    outFile.write("CHROM\tPOS\tPI\n")
    for line in inFile:
        tmp = line.strip().split('\t')
        if len(tmp)>1:
            pos = tmp[1]
            chrom = tmp[0]
            freqVals = [float(v.split(':')[1]) for v in tmp[4:]]
            H = 1 - sum([f*f for f in freqVals])
            outFile.write("{ch}\t{p}\t{pi}\n".format(ch=chrom,p=pos,pi=H))
    inFile.close()
    outFile.close()

def vcfAnalyse(inVCF,outFolder,refName,ploidy):

    vcfFilters="--minQ 60 --remove-indels --min-meanDP 10"
    outFiltered=os.path.join(outFolder,"GATK_HC_{}_filtered.vcf".format(refName))
    outFreq=os.path.join(outFolder,"vcftools_freq_{}.txt".format(refName))
    outFreqFilt=os.path.join(outFolder,"vcftools_freq_filtered_{}.txt".format(refName))
    outPi=os.path.join(outFolder,"vcftools_PI_{}.txt".format(refName))
    outPiFilt=os.path.join(outFolder,"vcftools_PI_filtered_{}.txt".format(refName))
    outCSV = os.path.join(outFolder,"genotyps_{}.csv".format(refName))
    indivFreqFld = os.path.join(outFolder,"Indiv_Freqs")
    dirFile_exist(indivFreqFld,1)
    indivList = get_indivListFromVCF(inVCF)

    cmd="vcftools --vcf {invcf} {filt} --recode --stdout > {outvcf}".format(invcf=inVCF,filt=vcfFilters,outvcf=outFiltered)
    os.system(cmd)

    cmd="vcftools --vcf {invcf} --freq --stdout > {freqtxt}".format(invcf=inVCF,freqtxt=outFreq)
    os.system(cmd)

    cmd="vcftools --vcf {invcf} {filt} --freq --stdout > {freqtxt}".format(invcf=inVCF,filt=vcfFilters,freqtxt=outFreqFilt)
    os.system(cmd)

    for ind in indivList:
        indName=ind.replace("PL:ILLUMINA","").strip()
        outFreqIndivFilt=os.path.join(indivFreqFld,"vcftools_freq_filtered_{}_{}.txt".format(refName,indName))
        cmd="vcftools --vcf {invcf} --indv \"{idName}\" --freq --stdout > {freqtxt}".format(invcf=outFiltered,freqtxt=outFreqIndivFilt,idName=ind)
        os.system(cmd)

    if ploidy>1:
        cmd="vcftools --vcf {invcf} --site-pi --stdout > {pitxt}".format(invcf=inVCF,pitxt=outPi)
        os.system(cmd)

        cmd="vcftools --vcf {invcf} {filt} --site-pi --stdout > {pitxt}".format(invcf=inVCF,filt=vcfFilters,pitxt=outPiFilt)
        os.system(cmd)
    else:
        calcul_div_allelique(outFreq,outPi)
        calcul_div_allelique(outFreqFilt,outPiFilt)

    get_alleles_fromVCF(outFiltered,outCSV)
    outReturn = {'pi':outPi,'piFiltered':outPiFilt,'freq':outFreq,'freqFiltered':outFreqFilt,'vcf':outFiltered}

    return outReturn



def get_alnFileName(AlnNames,indiv,header,ext=""):
    return "{head}_{aln}{ex}".format(head=header,ex=ext,aln=AlnNames[indiv])

def check_refIUPAC(refFile):

    print "Check reference file format..."

    code = "GATCRYWSMKHBVDN.-"
    ref = SeqIO.parse(refFile,"fasta")
    err = []
    for rec in ref:
        seq = str(rec.seq)
        if seq != seq.upper():
            err.append("{} -  contains lower case caracters".format(rec.id))
        pos=0
        for c in seq:
            pos+=1
            if c.upper() not in code:
                err.append("{}  -  contains forbiden caracter '{}' at pos:{}".format(rec.id,c,pos))

    if len(err)>0:
        print "\n".join(err)
        sys.exit("Quit program")

#Test if a file or directory exist if creatdir set to 0: exit
# if creatdir set to 1: create new directory
def dirFile_exist(path,creatdir = 0):

	if not os.path.exists(path):
		if (creatdir == 0):
			sys.exit("ERROR: {} not found".format(path))
		else:
			print "-- create {} directory".format(path)
			os.makedirs(path)

def load_readsList(readsList):
	rslt = {}
	
	rl = open(readsList,'r')
	
	readsDir = rl.readline().strip()
        abord = False
	for read in rl:
		read_info = read.strip().split(',')
                if read[0]!="#":
                    rslt[read_info[0]] = read_info[1:]
                    if len(read_info[1:])%2!=0:
                        abord=True
                        print "error {} reads number in list should be even (fq1_R1,fq1_R2,fq2_R1,fq2_R2,...)".format(read_info[0])
                    for fq in read_info[1:]:
                        if not os.path.exists(os.path.join(readsDir,fq)):
                            abord=True
                            print "error {} not exists".format(os.path.join(readsDir,fq))
	rl.close()
        if abord:
            sys.exit()

	return readsDir, rslt


if __name__=='__main__':
    
    ArgsVal = sys.argv[1:]
    run(ArgsVal)
