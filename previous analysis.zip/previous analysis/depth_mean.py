DP="profondeur.csv"
DP = open(str(DP), "r")
DP=DP.read()
DP = DP.split("\n")


BED="lyrata_control.bed" # fichier bed des regions concernées ok
BED = open(str(BED), "r")
BED=BED.read()
BED = BED.split("\n")


x2="max_depth_97.5.txt" 
fichier=open(str(x2), "a")

DEPTH2=[]
chrom=0
while chrom <= len(BED)-1:
    CHROM=BED[chrom]
    CHROM=CHROM.split("\t")
    deb=int(CHROM[1])
    fin=int(CHROM[2])
    Reg=CHROM[3]
    CHROM=CHROM[0]
    profondeur=[]
    j=0
    while j<=len(DP)-1:
        Bed2=DP[j]
        Bed2=Bed2.split("\t")
        if Bed2[0]== CHROM and int(Bed2[1])<= fin and int(Bed2[1])>= deb  : profondeur.append(Bed2)
        j=j+1
    ok=0
    if len(profondeur)>0:
        ok=1
    if ok==1 : # if cover
        i2=0
        
        while i2 <=len(profondeur)-1:
            Bed2=profondeur[i2]
            i=int(Bed2[1])
            x="\n"+str(CHROM)+';'+str(i)
            # we determine the mean depth of position
            DEPTH=0
            k=2
            while k <= len(Bed2)-1:
                DEPTH=DEPTH+int(Bed2[k])
                k=k+1
            DEPTH=float(DEPTH/(len(Bed2)-2))
            DEPTH2.append(DEPTH)
            i2=i2+1
            
    chrom=chrom+1
DEPTH2=sorted(DEPTH2)

                
x=round(len(DEPTH2)*0.97,0)
x=round(DEPTH2[int(x)],2)
fichier.write(str(x))
        
        


fichier.close()
