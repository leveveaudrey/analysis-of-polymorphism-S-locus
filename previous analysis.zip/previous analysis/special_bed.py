
BED="Arabidopsis_lyrata.v.1.0.23.gff3" # gff file of reference genome
BED = open(str(BED), "r")
BED=BED.read()
BED = BED.split("\n")


x2="lyrata_control_S_distance.bed" 
fichier=open(str(x2), "a")

window=2500

# coordonate of 5' region

CHROM="7" # name of chromosome of interest region
deb=9264431 # first position
fin=9339460 # last position

# filtration of GFF file
deb_gff=0
i=0
line=BED[i]
while line[0]=="#":
    i=i+1
    line=BED[i]
deb_gff=i

i=deb_gff
filtre=[]
line=BED[i]
while line!="":
    line=line.split("\t")
    if line[0]==CHROM and line[2]=="CDS":
        if int(line[3])>=deb and int(line[4])<= fin or int(line[3])<=deb and int(line[4])>=deb and int(line[4])<= fin or int(line[3])>=deb and int(line[3])<=fin and int(line[4])>= fin:
            filtre.append(line)
    i=i+1
    line=BED[i]

i=deb
while i+window<=fin:
    x="\n"+str(CHROM)+"\t"+str(i)+"\t"+str(i+2500)+"\t"+str((fin+1)-(i+2500))+"\t"
    cds=0
    j=0
    while j<=len(filtre)-1:
        line=filtre[j]
        if int(line[3])>=i and int(line[4])<= i+2500: #if entirely in window
            cds=cds+(int(line[4])-int(line[3])+1)
        if int(line[3])<=i and int(line[4])>=i and int(line[4])<= i+2500: #if end in window
            cds=cds+(int(line[4])-i+1)
        if int(line[3])>=i and int(line[3])<=i+2500 and int(line[4])>= i+2500 :# if beggin in window
            cds=cds+((i+2500)-int(line[3])+1)
        j=j+1
    x=str(x)+str(cds)
    fichier.write(str(x))
    i=i+window+1

# coordonate of 3' region

CHROM="7" # name of chromosome of interest region
deb=9376729 # first position
fin=9454259 # last position

# filtration of GFF file
deb_gff=0
i=0
line=BED[i]
while line[0]=="#":
    i=i+1
    line=BED[i]
deb_gff=i

i=deb_gff
filtre=[]
line=BED[i]
while line!="":
    line=line.split("\t")
    if line[0]==CHROM and line[2]=="CDS":
        if int(line[3])>=deb and int(line[4])<= fin or int(line[3])<=deb and int(line[4])>=deb and int(line[4])<= fin or int(line[3])>=deb and int(line[3])<=fin and int(line[4])>= fin:
            filtre.append(line)
    i=i+1
    line=BED[i]

i=deb
while i+window<=fin: 
    x="\n"+str(CHROM)+"\t"+str(i)+"\t"+str(i+2500)+"\t"+str(i-(deb-1))+"\t"
    cds=0
    j=0
    while j<=len(filtre)-1:
        line=filtre[j]
        if int(line[3])>=i and int(line[4])<= i+2500: #if entirely in window
            cds=cds+(int(line[4])-int(line[3])+1)
        if int(line[3])<=i and int(line[4])>=i and int(line[4])<= i+2500: #if end in window
            cds=cds+(int(line[4])-i+1)
        if int(line[3])>=i and int(line[3])<=i+2500 and int(line[4])>= i+2500 :# if beggin in window
            cds=cds+((i+2500)-int(line[3])+1)
        j=j+1
    x=str(x)+str(cds)
    fichier.write(str(x))
    i=i+window+1
        


fichier.close()
